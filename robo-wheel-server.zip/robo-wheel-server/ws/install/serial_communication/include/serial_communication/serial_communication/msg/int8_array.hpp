// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SERIAL_COMMUNICATION__MSG__INT8_ARRAY_HPP_
#define SERIAL_COMMUNICATION__MSG__INT8_ARRAY_HPP_

#include "serial_communication/msg/detail/int8_array__struct.hpp"
#include "serial_communication/msg/detail/int8_array__builder.hpp"
#include "serial_communication/msg/detail/int8_array__traits.hpp"

#endif  // SERIAL_COMMUNICATION__MSG__INT8_ARRAY_HPP_
