// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from serial_communication:msg/Int8Array.idl
// generated code does not contain a copyright notice

#ifndef SERIAL_COMMUNICATION__MSG__DETAIL__INT8_ARRAY__BUILDER_HPP_
#define SERIAL_COMMUNICATION__MSG__DETAIL__INT8_ARRAY__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "serial_communication/msg/detail/int8_array__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace serial_communication
{

namespace msg
{

namespace builder
{

class Init_Int8Array_data
{
public:
  Init_Int8Array_data()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::serial_communication::msg::Int8Array data(::serial_communication::msg::Int8Array::_data_type arg)
  {
    msg_.data = std::move(arg);
    return std::move(msg_);
  }

private:
  ::serial_communication::msg::Int8Array msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::serial_communication::msg::Int8Array>()
{
  return serial_communication::msg::builder::Init_Int8Array_data();
}

}  // namespace serial_communication

#endif  // SERIAL_COMMUNICATION__MSG__DETAIL__INT8_ARRAY__BUILDER_HPP_
